/*
Compile: make sum_even_cubes
Run: ./sum_even_cubes
*/

#include "base.h"

int sum_even_cubes(int n);

void sum_even_cubes_test(void) {
	// a)
}

int sum_even_cubes(int n) {
	// b)
	return 0;
}

int sum_even_cubes_rec(int n);

void sum_even_cubes_rec_test(void) {
	// a)
}

int sum_even_cubes_rec(int n) {
	// c)
	return 0;
}

int sum_even_cubes_rec2(int n);

void sum_even_cubes_rec2_test(void) {
	// a)
}

int sum_even_cubes_rec2(int n) {
	// d)
	return 0;
}

void timing(void) {
	// e)
}
/*
e)
*/

int main(void) {
    sum_even_cubes_test();
    sum_even_cubes_rec_test();
    sum_even_cubes_rec2_test();
	timing();
}
